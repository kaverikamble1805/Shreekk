<?php

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function SendContactEmail(
    $firstName,
    $lastName,
    $emailId,
    $subject,
    $message
) {

    $mail = new PHPMailer(true);

    try {

        // SMTP Settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;

        $mail->Username   = 'shaktimandir73@gmail.com';
        $mail->Password   = 'fihf zaoo azxf epsp';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Enable Debugging (Remove after testing)
        // $mail->SMTPDebug  = 2;
        // $mail->Debugoutput = 'html';

        // Sender
        $mail->setFrom(
            'shaktimandir73@gmail.com',
            'Website Contact Form'
        );

        // Receiver
        $mail->addAddress('shaktimandir73@gmail.com');

        // Reply To User
        $mail->addReplyTo(
            $emailId,
            $firstName . ' ' . $lastName
        );

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'New Contact Form Enquiry';

        $mail->Body = "
        <h2>New Contact Form Submission</h2>

        <p><strong>Name:</strong> {$firstName} {$lastName}</p>

        <p><strong>Email:</strong> {$emailId}</p>

        <p><strong>Subject:</strong> {$subject}</p>

        <p><strong>Message:</strong><br>{$message}</p>
        ";

        $mail->send();

        return [
            'success' => true,
            'message' => 'Email sent successfully.'
        ];

    } catch (Exception $e) {

        return [
            'success' => false,
            'message' => $mail->ErrorInfo
        ];
    }
}


/* Volunteer Form Email */
function SendVolunteerEmail(
    $firstName,
    $lastName,
    $phone,
    $email,
    $address,
    $city,
    $country,
    $zipCode,
    $subject,
    $thoughts,
    $consent
)
{
    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;

        $mail->Username = 'shaktimandir73@gmail.com';
        $mail->Password = 'fihf zaoo azxf epsp';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'shaktimandir73@gmail.com',
            'Volunteer Registration'
        );

        $mail->addAddress('shaktimandir73@gmail.com');

        $mail->isHTML(true);

        $mail->Subject = 'New Volunteer Registration';

        $mail->Body = "
        <h3>New Volunteer Registration</h3>

        <b>First Name:</b> {$firstName}<br>
        <b>Last Name:</b> {$lastName}<br>
        <b>Phone:</b> {$phone}<br>
        <b>Email:</b> {$email}<br>
        <b>Address:</b> {$address}<br>
        <b>City:</b> {$city}<br>
        <b>Country:</b> {$country}<br>
        <b>Post Code:</b> {$zipCode}<br>
                <b>Subject:</b> {$subject}<br>
        <b>Thoughts:</b> {$thoughts}<br>
        <b>Consent:</b> " . ($consent ? 'Yes' : 'No') . "
        ";

        $mail->send();

        return true;

    } catch (Exception $e) {
        return false;
    }
}
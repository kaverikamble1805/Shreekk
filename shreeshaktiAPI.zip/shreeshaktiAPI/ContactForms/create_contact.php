<?php

include 'cors.php';
include 'db.php';
include 'email.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "No data received"
    ]);
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO contact_us
    (
        FirstName,
        LastName,
        PhoneNo,
        EmailId,
        Subject,
        Message
    )
    VALUES
    (
        ?,?,?,?,?,?
    )
");

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => $conn->error
    ]);
    exit;
}

$stmt->bind_param(
    "ssssss",
    $data['FirstName'],
    $data['LastName'],
    $data['PhoneNo'],
    $data['EmailId'],
    $data['Subject'],
    $data['Message']
);

if ($stmt->execute()) {

    $emailResult = SendContactEmail(
        $data['FirstName'],
        $data['LastName'],
        $data['EmailId'],
        $data['Subject'],
        $data['Message']
    );

    echo json_encode([
        "success" => true,
        "message" => "Contact saved successfully",
        "emailStatus" => $emailResult
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => $stmt->error
    ]);
}

$stmt->close();
$conn->close();
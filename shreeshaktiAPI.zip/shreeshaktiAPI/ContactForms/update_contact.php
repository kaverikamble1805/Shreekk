<?php

include 'cors.php';
include 'db.php';

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$stmt = $conn->prepare(
"UPDATE ContactUs
SET
FirstName=?,
LastName=?,
EmailId=?,
Address=?,
Message=?
WHERE Id=?"
);

$stmt->bind_param(
"sssssi",
$data['firstName'],
$data['lastName'],
$data['emailId'],
$data['address'],
$data['message'],
$data['id']
);

if($stmt->execute())
{
    echo json_encode([
        "success"=>true,
        "message"=>"Updated Successfully"
    ]);
}
else
{
    echo json_encode([
        "success"=>false,
        "message"=>$stmt->error
    ]);
}
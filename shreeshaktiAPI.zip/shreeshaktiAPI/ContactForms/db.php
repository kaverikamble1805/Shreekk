<?php

$servername = "localhost";
$username   = "shreeshaktitempl_shree";
$password   = "Shree@vct2026";
$database   = "shreeshaktitempl_contactus";

$conn = new mysqli(
    $servername,
    $username,
    $password,
    $database
);

if ($conn->connect_error) {

    die(json_encode([
        "success" => false,
        "message" => $conn->connect_error
    ]));
}
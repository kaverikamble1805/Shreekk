<?php

include 'cors.php';
include 'db.php';

$result = $conn->query(
    "SELECT * FROM ContactUs
     ORDER BY Id DESC"
);

$data = [];

while($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $data
]);
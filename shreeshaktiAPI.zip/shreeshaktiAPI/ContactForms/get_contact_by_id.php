<?php

include 'cors.php';
include 'db.php';

$id = $_GET['id'];

$stmt = $conn->prepare(
    "SELECT * FROM ContactUs
     WHERE Id=?"
);

$stmt->bind_param("i",$id);

$stmt->execute();

$result = $stmt->get_result();

echo json_encode([
    "success" => true,
    "data" => $result->fetch_assoc()
]);
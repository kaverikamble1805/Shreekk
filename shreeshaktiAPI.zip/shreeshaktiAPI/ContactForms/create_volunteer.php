<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

include 'cors.php';
include 'db.php';
include 'email.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON data"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO volunteers
    (
        FirstName,
        LastName,
        Phone,
        EmailId,
        Address,
        City,
        Country,
        ZipCode,
        Subject,
        Thoughts,
        Consent
    )
    VALUES
    (
        ?,?,?,?,?,?,?,?,?,?,?
    )"
);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => $conn->error
    ]);
    exit;
}

$stmt->bind_param(
    "ssssssssssi",
    $data['FirstName'],
    $data['LastName'],
    $data['PhoneNo'],
    $data['EmailId'],
    $data['Address'],
    $data['City'],
    $data['Country'],
    $data['ZipCode'],
    $data['Subject'],
    $data['Thoughts'],
    $data['Consent']
);

if (!$stmt->execute()) {

    echo json_encode([
        "success" => false,
        "message" => $stmt->error
    ]);

    exit;
}

$emailSent = SendVolunteerEmail(
    $data['FirstName'],
    $data['LastName'],
    $data['PhoneNo'],
    $data['EmailId'],
    $data['Address'],
    $data['City'],
    $data['Country'],
    $data['ZipCode'],
    $data['Subject'],
    $data['Thoughts'],
    $data['Consent']
);

echo json_encode([
    "success" => true,
    "message" => $emailSent
        ? "Jai Mata Di! Volunteer registration submitted successfully."
        : "Registration submitted, but email could not be sent."
]);

$stmt->close();
$conn->close();

?>